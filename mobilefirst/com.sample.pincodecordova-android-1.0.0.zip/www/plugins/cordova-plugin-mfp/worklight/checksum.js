var WL_CHECKSUM = {"checksum":721805596,"date":1518076461600,"machine":"Settawat-SRS"}
/* Date: Thu Feb 08 2018 14:54:21 GMT+0700 (SE Asia Standard Time) */